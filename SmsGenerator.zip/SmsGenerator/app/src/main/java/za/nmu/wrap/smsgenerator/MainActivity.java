package za.nmu.wrap.smsgenerator;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
EditText  contactNum, etMessageCount, etStartDate,etEndDate,  etCustomMessage;
Button   btnSendBatch,btnSendCustom;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        contactNum = findViewById(R.id.contactNum);
        etMessageCount = findViewById(R.id.etMessageCount);
        etStartDate = findViewById(R.id.etStartDate);
        etEndDate = findViewById(R.id.etEndDate);
        etCustomMessage = findViewById(R.id.etCustomMessage);
        btnSendBatch = findViewById(R.id.btnSendBatch);
        btnSendCustom = findViewById(R.id.btnSendCustom);

        // Generate and send random batch messages
        btnSendBatch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(ContextCompat.checkSelfPermission(MainActivity.this, android.Manifest.permission.SEND_SMS)
                        == PackageManager.PERMISSION_GRANTED){
                    int messageCount = Integer.parseInt(etMessageCount.getText().toString());
                    generateAndSendBatchMessages(messageCount);
                }
                else{
                    ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.SEND_SMS},100);
                }
            }
        });

        // Send custom message
        btnSendCustom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String customMessage = etCustomMessage.getText().toString();
                sendSMS(contactNum.getText().toString(), customMessage);
            }
        });

    }
    // Generate random SMS messages in batch
    private void generateAndSendBatchMessages(int count) {
        for (int i = 0; i < count; i++) {
            String randomMessage = generateRandomMessage();
            sendSMS(contactNum.getText().toString(), randomMessage);
        }
    }

    // Send SMS to the emulator number
    private void sendSMS(String phoneNumber, String message) {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            if(!contactNum.getText().toString().isEmpty() && Integer.parseInt(etMessageCount.getText().toString())>0){
                smsManager.sendTextMessage(phoneNumber,null, message,null,null);
                Toast.makeText(getApplicationContext(), "SMS Sent", Toast.LENGTH_LONG).show();
                etCustomMessage.setText(message);
            }

        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), "SMS Failed to Send", Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }

    public void SendCustomBtnClicked(View view) {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            if(!contactNum.getText().toString().isEmpty() && Integer.parseInt(etMessageCount.getText().toString())>0){
                smsManager.sendTextMessage("5556",null, etCustomMessage.getText().toString(),null,null);
                Toast.makeText(getApplicationContext(), "SMS Sent", Toast.LENGTH_LONG).show();
            }
        }
        catch (Exception e) {
            Toast.makeText(getApplicationContext(), "SMS Failed to Send", Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }

    private String generateRandomMessage() {
        Random rand = new Random();

        // Decide whether to generate a financial message or a general message
        boolean isFinancialMessage = rand.nextBoolean(); // 50/50 chance

        if (isFinancialMessage) {
            // List of institutions and account types
            String[] institutions = {
                    "Absa: CHEQ5678", "Capitec: SAV0012", "WFS: CCRD2345",
                    "Absa: CHEQ1234", "Capitec: SAV9876", "WFS: CCRD4567",
                    "Absa: CHEQ0987", "Capitec: SAV2345", "WFS: CCRD1013",
                    "Absa: CHEQ3456", "Capitec: SAV5678", "WFS: CCRD7777",
                    "Absa: CHEQ6543", "Capitec: SAV1112", "WFS: CCRD9098"
            };

            // List of transaction types
            String[] transactionTypes = {
                    "Pur", "Wthdr", "Dep", "Pmnt", "Sch t", "Transf"
            };

            // List of descriptions for the transactions
            String[] descriptions = {
                    "SETTLEMENT/C - GROCERY PURCHASE, SPAR: 0312547891",
                    "ATM WITHDRAWAL, MAIN BRANCH ATM",
                    "SETTLEMENT/C – SALARY CREDIT, ABC CORP",
                    "SETTLEMENT/C - DIGITAL PAYMENT DT, MY RENTAL ACCOMMODATION",
                    "ACB DEBIT: INSURANCE, ABC INSURANCE",
                    "AUTHORIZATION, COFFEE SHOP: 0431254796",
                    "ONLINE PURCHASE, TAKEALOT.COM",
                    "INTERNAL FUNDS TRANSFER, ***1018",
                    "SETTLEMENT/C - RENTAL PAYMENT DT, LANDLORD ACCOUNT",
                    "DEPOSIT, MOBILE BANKING",
                    "AUTHORIZATION, WOOLWORTHS CAPE TOWN",
                    "SETTLEMENT/C - GYM MEMBERSHIP DEBIT, PLANET FITNESS",
                    "ATM DEPOSIT, MALL BRANCH ATM",
                    "AUTHORIZATION, WOOLIES FOOD WALMER"
            };

            // Random transaction amounts (positive initially)
            String[] amounts = {
                    "149.00", "500.00", "20000.00", "10000.00", "865.00",
                    "300.00", "1000.00", "1200.00", "7500.00", "450.00",
                    "799.00", "5000.00", "750.00", "1250.00", "350.00"
            };

            // Random available balance
            String[] availableBalances = {
                    "R1,000.00", "R500.00", "R21,000.00", "R11,000.00", "R8,500.00",
                    "R5,200.00", "R8,500.00", "R2,800.00", "R18,000.00", "R12,500.00",
                    "R1,500.00", "R3,200.00", "R6,500.00", "R2,100.00", "R4,000.00"
            };

            // Random dates
            String[] dates = {
                    "02/12/23", "15/04/21", "29/01/24", "02/09/23", "20/04/23",
                    "12/05/23", "09/06/23", "03/07/23", "13/10/23", "11/11/22",
                    "25/03/23", "15/08/23", "22/07/23", "30/09/23", "12/06/23"
            };

            // Random help lines and account ID
            String[] helpLines = {
                    "Help 0860008600; ACCID 001", "Help 0860102040; ACCID 010",
                    "Help 0861502005; CCID 003", "Help 0860008600; ACCID 002",
                    "Help 0861502005; CCID 004", "Help 0861502005; CCID 005"
            };

            // Generate a random transaction by selecting a random value from each list
            String institution = institutions[rand.nextInt(institutions.length)];
            String transactionType = transactionTypes[rand.nextInt(transactionTypes.length)];
            String description = descriptions[rand.nextInt(descriptions.length)];
            String amount = amounts[rand.nextInt(amounts.length)];
            String availableBalance = availableBalances[rand.nextInt(availableBalances.length)];
            String date = dates[rand.nextInt(dates.length)];
            String helpLine = helpLines[rand.nextInt(helpLines.length)];

            // If the transaction is NOT a "Dep" (Deposit) or "Transf" (Transfer), prepend a negative sign to the amount
            if (!transactionType.equals("Dep") && !transactionType.equals("Transf")) {
                amount = "-R" + amount;
            } else {
                amount = "R" + amount;
            }

            // Format the financial message
            String message = String.format(
                    "%s, %s, %s %s, %s, Available %s. %s",
                    institution, transactionType, date, description, amount, availableBalance, helpLine
            );

            return message;

        } else {
            // Generate a general message
            String[] generalMessages = {
                    "You've won 1,000,000 USD!!!",
                    "Congratulations! You've been selected for a prize!",
                    "Act now and claim your free vacation!",
                    "You have been entered into a sweepstake for a chance to win a car!",
                    "Important: Update your banking details to avoid service interruptions."
            };

            // Return a random general message
            return generalMessages[rand.nextInt(generalMessages.length)];
        }
    }


}