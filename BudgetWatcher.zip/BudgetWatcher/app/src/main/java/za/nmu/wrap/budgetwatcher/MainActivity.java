package za.nmu.wrap.budgetwatcher;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private Transaction_Adapter transactionAdapter;
    private List<Transaction> transactionList;
    private  List<Transaction> filteredTransactionList;

    TextView totalText; TextView totalAmt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Initialize the RecyclerView
        recyclerView = findViewById(R.id.RecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Initialize the transaction list
        transactionList = new ArrayList<>();

        totalText = findViewById(R.id.totalAmtView);
        totalAmt = findViewById(R.id.totalAmt);
        // Set up the adapter with the transaction list
        transactionAdapter = new Transaction_Adapter(transactionList);
        recyclerView.setAdapter(transactionAdapter);

        // Set up the FAB to filter transactions by tags
        FloatingActionButton fabFilter = findViewById(R.id.fabFilter);
        fabFilter.setOnClickListener(v -> showFilterActivity());////

        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this,"Permission not granted", Toast.LENGTH_SHORT);
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_SMS}, 1);
            processSMSMessages();
        }
        else{
            processSMSMessages();
            Toast.makeText(this, "There are "+transactionList.size()+"transactions in the list", Toast.LENGTH_LONG).show();
            tagTransactions(transactionList);
        
        }

    }
    private static final int FILTER_REQUEST_CODE = 1;
    private void showFilterActivity() {
        Intent intent = new Intent(this, FilterActivity.class);
        startActivityForResult(intent, FILTER_REQUEST_CODE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILTER_REQUEST_CODE && resultCode == RESULT_OK) {
            if (data != null) {
                List<String> selectedTags = data.getStringArrayListExtra("selectedTags");
                String startdate = data.getStringExtra("startDate");
                String enddate = data.getStringExtra("endDate");

                // Process the filters as before
                if (selectedTags != null && !selectedTags.isEmpty()) {
                    List<Transaction> taggedTransactions = filterTransactionsByTags(selectedTags);
                    if (taggedTransactions != null) {

                        if (startdate != null || enddate != null) {
                            try {
                                Toast.makeText(this,"From "+startdate +" to "+enddate,Toast.LENGTH_LONG).show();
                                displayTransactionsWithinDateRange(taggedTransactions, startdate, enddate);
                            } catch (Exception e) {
                                Toast.makeText(this,e.toString(),Toast.LENGTH_SHORT);
                                throw new RuntimeException(e);
                            }
                        } else {
                            // If dates are empty, just show the filtered transactions by tags
                            transactionAdapter = new Transaction_Adapter(taggedTransactions);
                            transactionAdapter.notifyDataSetChanged();
                            recyclerView.setAdapter(transactionAdapter);
                        }
                    }
                } else {

                    if (startdate != null || enddate != null) {
                        try {
                            Toast.makeText(this,"From "+startdate +" to "+enddate,Toast.LENGTH_LONG).show();
                            displayTransactionsWithinDateRange(transactionList, startdate, enddate);
                        } catch (Exception e) {
                            Toast.makeText(this,e.toString(),Toast.LENGTH_SHORT);
                            throw new RuntimeException(e);
                        }
                    } else {
                        // If dates are empty, just show the filtered transactions by tags
                        transactionAdapter = new Transaction_Adapter(transactionList);
                        transactionAdapter.notifyDataSetChanged();
                        recyclerView.setAdapter(transactionAdapter);
                    }
                    totalAmt.setVisibility(View.INVISIBLE);
                    totalText.setVisibility(View.INVISIBLE);
                }
            }
        }
    }



    private List<Transaction> filterTransactionsByTags(List<String> selectedTags) {
        // Create a list to hold tagged transactions
        List<Transaction> taggedTransactions = new ArrayList<>();

        // If no tags are selected, return the full list
        if (selectedTags.isEmpty()) {
            return transactionList;
        }

        // Filter the transactions by tags
        for (Transaction transaction : transactionList) {
            if (transaction.getTags().containsAll(selectedTags)) {
                taggedTransactions.add(transaction);
            }
        }

        // Display the filtered transactions
        if (taggedTransactions.isEmpty()) {
            Toast.makeText(this, "No transactions match the selected date range.", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, taggedTransactions.size() + " transactions match the date range.", Toast.LENGTH_SHORT).show();

            // Update RecyclerView with the filtered list
            transactionAdapter = new Transaction_Adapter(taggedTransactions);
            transactionAdapter.notifyDataSetChanged();
            recyclerView.setAdapter(transactionAdapter);

            // Calculate and display the total amount
            totalText.setVisibility(View.VISIBLE);
            totalAmt.setVisibility(View.VISIBLE);
            double total = 0;
            for (Transaction transaction : taggedTransactions) {
                try {
                    String amountStr = transaction.getAmount().replace("R", "").replace(",", "");
                    total += Double.parseDouble(amountStr);
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                    Toast.makeText(this, "Error parsing amount for transaction.", Toast.LENGTH_SHORT).show();
                }
            }
            String totalAmount = String.format("R%.2f", total);
            totalAmt.setText(totalAmount);
        }

        return taggedTransactions;
    }

    private void displayTransactionsWithinDateRange(List<Transaction> taggedTransactions, String startDate, String endDate) throws Exception {
        // Filter the tagged transactions by date range
        List<Transaction> filteredTransactions = new ArrayList<>();

        // Convert the dates to DD/MM/YY integers
        int start = (startDate != null && !startDate.isEmpty()) ? convertDateToInt(startDate) : Integer.MIN_VALUE;
        int end = (endDate != null && !endDate.isEmpty()) ? convertDateToInt(endDate) : Integer.MAX_VALUE;

        for (Transaction transaction : taggedTransactions) {
            boolean dateMatch = true;

            // Safely parse transaction date
            try {
                int transactionDateInt = convertDateToInt(transaction.getDate());

                if (transactionDateInt < start || transactionDateInt > end) {
                    dateMatch = false;
                }

            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(this, "Invalid transaction date found.", Toast.LENGTH_SHORT).show();
                continue; // Skip this transaction if date parsing fails
            }

            // Add the transaction if the date matches the range
            if (dateMatch) {
                filteredTransactions.add(transaction);
            }
        }

        // Display the filtered transactions
        if (filteredTransactions.isEmpty()) {
            Toast.makeText(this, "No transactions match the selected date range.", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, filteredTransactions.size() + " transactions match the date range.", Toast.LENGTH_SHORT).show();

            // Update RecyclerView with the filtered list
            transactionAdapter = new Transaction_Adapter(filteredTransactions);
            transactionAdapter.notifyDataSetChanged();
            recyclerView.setAdapter(transactionAdapter);

            // Calculate and display the total amount
            totalText.setVisibility(View.VISIBLE);
            totalAmt.setVisibility(View.VISIBLE);
            double total = 0;
            for (Transaction transaction : filteredTransactions) {
                try {
                    String amountStr = transaction.getAmount().replace("R", "").replace(",", "");
                    total += Double.parseDouble(amountStr);
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                    Toast.makeText(this, "Error parsing amount for transaction.", Toast.LENGTH_SHORT).show();
                }
            }
            String totalAmount = String.format("R%.2f", total);
            totalAmt.setText(totalAmount);
        }
    }

    // Helper method to convert date in DD/MM/YY format to an integer for easy comparison
    private int convertDateToInt(String date) throws Exception {
        String[] dateParts = date.split("/");
        if (dateParts.length != 3) {
            throw new Exception("Invalid date format.");
        }

        // Convert date parts to integers
        int day = Integer.parseInt(dateParts[0]);
        int month = Integer.parseInt(dateParts[1]);
        int year = Integer.parseInt(dateParts[2]);

        // Return a composite integer that can be compared (YYMMDD format)
        return (year * 10000) + (month * 100) + day;
    }

    private void tagTransactions(List<Transaction> transactionList){
        for(Transaction transaction:transactionList){
            if(transaction.getAmount().contains("-")){
                transaction.addTag("Expense");
            }
            else {
                transaction.addTag("Income");
            }
            if(transaction.getDescription().contains("GROCERY") || transaction.getDescription().contains("FOOD")){
                transaction.addTag("Food");
            }
        }
    }

    private void processSMSMessages() {
        List<String> financialMessages = new ArrayList<>();

        Uri smsUri = Uri.parse("content://sms/inbox");
        Cursor smsCursor = getContentResolver().query(smsUri, null, null, null, null);

        if (smsCursor != null && smsCursor.moveToFirst()) {
            do {
                String body = smsCursor.getString(smsCursor.getColumnIndexOrThrow("body"));
                String sender = smsCursor.getString(smsCursor.getColumnIndexOrThrow("address"));

                if (isFinancialInstitutionMessage(body, sender)) {
                    financialMessages.add(body);
                    // Process and parse message
                    Transaction transaction = parseTransaction(body);
                    if(transaction != null){
                        transactionList.add(transaction);
                        // Toast.makeText(this, "transasction added to list", Toast.LENGTH_SHORT).show();
//                    if (transaction != null) {
//                        // Tagging and further processing logic
//                        List<String> tags = tagTransaction(transaction);
//                        // Aggregate and display results
//                    }
                    }
                }
            } while (smsCursor.moveToNext());
            smsCursor.close();
        }
        transactionAdapter = new Transaction_Adapter(transactionList);
        transactionAdapter.notifyDataSetChanged();
        recyclerView.setAdapter(transactionAdapter);
    }

    // Check if SMS message is from financial institutions like ABSA, WFS
    private boolean isFinancialInstitutionMessage(String body, String sender) {
        String pattern = "(Absa|Capitec|WFS):";
        Pattern r = Pattern.compile(pattern);
        Matcher m = r.matcher(body);
        //Toast.makeText(this,"Message is a financial message",Toast.LENGTH_LONG).show();
        return m.find();
    }

    //        String[] SMS = message.split(",");
//        return  new Transaction(SMS[0],SMS[1], SMS[2], SMS[3], SMS[4], SMS[5], SMS[5]);
    private Transaction parseTransaction(String message) {
        // Adjusted pattern to handle multiple institutions (Absa, Capitec, Woolworths Financial Services)
        Pattern pattern = Pattern.compile(
                "(Absa|Capitec|WFS): ([A-Z0-9]+),(\\D+), " +
                        "(\\d{2}/\\d{2}/\\d{2}) (.*?), " +
                        "((-R[0-9]*\\.?[0-9]+)|(R[0-9]*\\.?[0-9]+))," +
                        " Available (R[0-9]*\\.?[0-9]+)"
        );
        Matcher matcher = pattern.matcher(message);

        if (matcher.find()) {
            String institution = matcher.group(1);    // Captures the institution (Absa, Capitec, WFS)
            String account = matcher.group(2);        // Captures the account number (e.g., CHEQ5678)
            String type = matcher.group(3);           // Captures the transaction type (e.g., Pur, Wthdr)
            String date = matcher.group(4);           // Captures the date of the transaction (e.g., 02/12/23)
            String description = matcher.group(5);    // Captures the description (e.g., GROCERY PURCHASE)
            String amount = matcher.group(6);         // Captures the amount (e.g., -R149.00)
            String balance = matcher.group(7);        // Captures the available balance (e.g., R1000.00)

            // Return a Transaction object populated with the parsed information
            return new Transaction(institution, account, type, date, description, amount, balance);
        }

        return null; // Return null if no match is found
    }

    private List<String> tagTransaction(Transaction transaction) {
        List<String> tags = new ArrayList<>();

        // Check for food-related keywords
        if (transaction.getDescription().toLowerCase().contains("restaurant") ||
                transaction.getDescription().toLowerCase().contains("coffee")) {
            tags.add("food");
            tags.add("restaurant");
        }

        // Check for transport-related keywords
        if (transaction.getDescription().toLowerCase().contains("fuel") ||
                transaction.getDescription().toLowerCase().contains("uber")) {
            tags.add("transport");
        }

        // General tag for expenses
        if (transaction.getAmount().startsWith("-")) {
            tags.add("expense");
        } else {
            tags.add("income");
        }
        return tags;
    }
    private double aggregateTransactions(List<Transaction> transactions, String tag, String startDate, String endDate) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yy");
        double total = 0;

        for (Transaction transaction : transactions) {
            if (transaction.getTags().contains(tag)) {
                try {
                    Date transactionDate = sdf.parse(transaction.getDate());
                    Date start = sdf.parse(startDate);
                    Date end = sdf.parse(endDate);

                    if (transactionDate.after(start) && transactionDate.before(end)) {
                        total += Double.parseDouble(transaction.getAmount().replace("R", ""));
                    }
                } catch (ParseException e) {
                    e.printStackTrace();
                }
            }
        }

        return total;
    }
}

