package za.nmu.wrap.budgetwatcher;

import java.util.ArrayList;
import java.util.List;

public class Transaction {
    private String institution;     // Bank or financial institution (e.g., Absa, WFS)
    private String account;         // Account number (e.g., CHEQ1234)
    private String type;            // Type of transaction (e.g., Pur, Wthdr, Dep)
    private String date;            // Date of transaction (e.g., 02/12/23)
    private String description;     // Description of transaction (e.g., SETTLEMENT/C - AIRTIME DEBIT)
    private String amount;          // Transaction amount (e.g., R-149.00)
    private String balance;         // Available balance after transaction (e.g., Available R1000.00)
    private List<String> tags;      // List of tags assigned to this transaction (e.g., food, expense, restaurant)

    public Transaction(String institution, String account, String type, String date, String description, String amount, String balance) {
        this.institution = institution;
        this.account = account;
        this.type = type;
        this.date = date;
        this.description = description;
        this.amount = amount;
        this.balance = balance;
        this.tags =new ArrayList<>(); // Initialize with an empty list of tags
    }

    public String getInstitution() {
        return institution;
    }

    public void setInstitution(String institution) {
        this.institution = institution;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getBalance() {
        return balance;
    }

    public void setBalance(String balance) {
        this.balance = balance;
    }

    public List<String> getTags() {
        return tags;
    }

    public void setTags(List<String> tags) {
        this.tags = tags;
    }

    // Add a single tag to the transaction
    public void addTag(String tag) {
        if (!tags.contains(tag)) {
            tags.add(tag);
        }
    }

    // Add multiple tags to the transaction
    public void addTags(List<String> tags) {
        for (String tag : tags) {
            if (!this.tags.contains(tag)) {
                this.tags.add(tag);
            }
        }
    }

    @Override
    public String toString() {
        return "Transaction{" +
                "institution='" + institution + '\'' +
                ", account='" + account + '\'' +
                ", type='" + type + '\'' +
                ", date='" + date + '\'' +
                ", description='" + description + '\'' +
                ", amount='" + amount + '\'' +
                ", balance='" + balance + '\'' +
                ", tags=" + tags +
                '}';
    }
}
