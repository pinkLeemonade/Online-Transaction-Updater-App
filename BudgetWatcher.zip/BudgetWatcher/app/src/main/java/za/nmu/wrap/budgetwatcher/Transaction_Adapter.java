package za.nmu.wrap.budgetwatcher;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class Transaction_Adapter extends RecyclerView.Adapter<Transaction_Adapter.ViewHolder> {
    private List<Transaction> transactions;
    public Transaction_Adapter(List<Transaction> transactions) {

        this.transactions = transactions;
    }


    @NonNull
    @Override
    public Transaction_Adapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.transaction_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Transaction_Adapter.ViewHolder holder, int position) {
        Transaction transaction = transactions.get(position);
        holder.bind(transaction);
    }

    @Override
    public int getItemCount() {
        return transactions.size();
    }
    public void notifyItemRemoved(Transaction transaction) {
        notifyDataSetChanged();
    }


    public class ViewHolder  extends RecyclerView.ViewHolder{

        TextView description, amount, date;

        public ViewHolder(View itemView) {
            super(itemView);
            description = itemView.findViewById(R.id.tvDescription);
            amount = itemView.findViewById(R.id.tvAmount);
            date = itemView.findViewById(R.id.tvDate);
        }

        public void bind(Transaction transaction) {
            description.setText(transaction.getDescription());
            amount.setText(transaction.getAmount());
            date.setText(transaction.getDate());
        }
    }

}
