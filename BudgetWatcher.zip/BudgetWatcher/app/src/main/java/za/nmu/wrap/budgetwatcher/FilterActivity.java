package za.nmu.wrap.budgetwatcher;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;

import java.util.ArrayList;
import java.util.List;

public class FilterActivity extends AppCompatActivity {
    private List<String> selectedTags = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_filter);
        // Get references to the CheckBoxes
        CheckBox checkBoxIncome = findViewById(R.id.checkBoxIncome);

        CheckBox checkBoxExpense = findViewById(R.id.checkBoxExpense);
        CheckBox checkBoxFood = findViewById(R.id.checkBoxFood);
        CheckBox checkBoxRestaurant = findViewById(R.id.checkBoxRestaurant);
        CheckBox checkBoxTransport = findViewById(R.id.checkBoxTransport);
        EditText startDate = findViewById(R.id.startDatetext);
        EditText endDate = findViewById(R.id.endDatetext);

        // Set up buttons to handle apply and clear filter actions
        Button btnApplyFilters = findViewById(R.id.btnApplyFilters);
        Button btnClearFilters = findViewById(R.id.btnClearFilters);

        btnApplyFilters.setOnClickListener(v -> {
            selectedTags.clear();
            if (checkBoxIncome.isChecked()) selectedTags.add("Income");
            if (checkBoxExpense.isChecked()) selectedTags.add("Expense");
            if (checkBoxFood.isChecked()) selectedTags.add("Food");
            if (checkBoxRestaurant.isChecked()) selectedTags.add("Restaurant");
            if (checkBoxTransport.isChecked()) selectedTags.add("Transport");

            Intent resultIntent = new Intent();
            resultIntent.putStringArrayListExtra("selectedTags", new ArrayList<>(selectedTags));
            resultIntent.putExtra("startDate", startDate.getText().toString());
            resultIntent.putExtra("endDate", endDate.getText().toString());
            setResult(RESULT_OK, resultIntent);
            //Saving checkbox states before closing the activity.
            SharedPreferences sharedPreferences = getSharedPreferences("CheckboxStates", MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putBoolean("isIncomeChecked", checkBoxIncome.isChecked());
            editor.putBoolean("isExpenseChecked", checkBoxExpense.isChecked());
            editor.putBoolean("isFoodChecked", checkBoxFood.isChecked());
            editor.putBoolean("isRestaurantChecked", checkBoxRestaurant.isChecked());
            editor.putBoolean("isTransportChecked", checkBoxTransport.isChecked());
            editor.apply();


            finish(); // Close the activity


        });

        btnClearFilters.setOnClickListener(v -> {
            checkBoxIncome.setChecked(false);
            checkBoxExpense.setChecked(false);
            checkBoxFood.setChecked(false);
            checkBoxRestaurant.setChecked(false);
            checkBoxTransport.setChecked(false);
            startDate.setText("");
            endDate.setText("");

        });

    }

}
